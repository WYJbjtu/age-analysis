# English Member 4 presentation package

Use these sections in the existing group poster/report. They do not replace the whole group artifact.

- [Report section](report_section.md): ready-to-integrate English analysis and limitations.
- [Poster text and layout](poster_text.md): concise copy, hierarchy and placement.
- [Speaking script](speaking_script.md): 364 spoken words, approximately three minutes at 120 words per minute, including the Member 3 transition and group conclusion.
- [Figure captions](figure_captions.md): defined samples, periods, sources and limitations.
- [Five examiner questions](examiner_qa.md): short evidence-based answers.

Use [Figure 1](../../analysis/member4/figures/01_pooled_within_2022.svg) as the main Member 4 chart, [Figure 2](../../analysis/member4/figures/02_robustness_and_covariance.svg) as support, and [Figure 3](../../analysis/member4/figures/03_within_country_cases.svg) as an optional case bridge/appendix. PNG companions have the same stem and 300 dpi.

The presentation takeaway is **aggregation changes the interpretation, without a robust direction-reversal headline**. Pearson does not reverse in 2022; Spearman has a nominal reversal with weak within-country coefficients and an unstable U.S. sign. Keep the country and period caveats with the figures. Do not reintroduce the unsupported Member 3 labor reversal wording or use its clipped Figure 4 until its owner fixes it. Detailed audit and source evidence live in [Member 4's audit](../../analysis/member4/audit_report.md).
